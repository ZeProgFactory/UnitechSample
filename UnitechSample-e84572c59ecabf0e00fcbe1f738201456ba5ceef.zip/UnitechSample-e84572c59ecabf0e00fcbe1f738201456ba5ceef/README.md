# UnitechSample
Xamarin.Forms sample app for Unitech EA510 (EA502) barcode terminals

![Screenshot](/Screenshot/Screenshot.png)
