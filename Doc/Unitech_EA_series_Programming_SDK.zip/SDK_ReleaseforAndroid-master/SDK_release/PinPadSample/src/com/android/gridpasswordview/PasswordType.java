package com.android.gridpasswordview;

public enum PasswordType {

    NUMBER, TEXT, TEXTVISIBLE, TEXTWEB;

}
