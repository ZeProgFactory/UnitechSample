﻿using System;
using static System.Text.Encoding;
using Android.App;

using Android.Device;
//using static Android.Device.ScanManager;
//using static Android.Device.Scanner.Configuration.PropertyID;
//using static Android.Device.Scanner.Configuration.Triggering;

using Android.OS;
//using Android.Runtime;
//using Android.Support.Design.Widget;
using Android.Support.V7.App;
//using Android.Views;
using Android.Widget;
using Android.Content;

namespace EAseries_Barcode_1._2_Xamarin
{
    [Activity(Label = "@string/app_name", Theme = "@style/AppTheme.NoActionBar", MainLauncher = true)]
    public class MainActivity : AppCompatActivity
    {
        //private string TAG = typeof(MainActivity).Name;
        private static MainActivity mInst = null;
        //private static String SCAN_ACTION = ScanManager.ActionDecode;
        //private ScanManager mScanManager;
        //private TextView tvScanResult;

        [BroadcastReceiver(Name = "com.ute.eu.ScanResultReceiver", Enabled = true)]
        [IntentFilter(new[] { ScanManager.ActionDecode })]
        public class ScanResultReceiver : BroadcastReceiver
        {

            public override void OnReceive(Context context, Intent intent)
            {
                MainActivity inst = Instance();

                if (inst != null)
                    inst.SetViewText("");

                byte[] barcode = intent.GetByteArrayExtra(ScanManager.DecodeDataTag);
                //int barcodelen = intent.GetIntExtra(ScanManager.BarcodeLengthTag, 0);
                //byte sym = intent.GetByteExtra(ScanManager.BarcodeTypeTag, (byte)0);
                string result = UTF8.GetString(barcode);

                if (inst != null)
                    inst.SetViewText(result);
            }
        };

        public static MainActivity Instance()
        {
            return mInst;
        }

        public void SetViewText(String txt)
        {
            TextView txtView = (TextView)FindViewById(Resource.Id.tvScanResult);
            txtView.Text = txt;
        }

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            Xamarin.Essentials.Platform.Init(this, savedInstanceState);
            SetContentView(Resource.Layout.activity_main);
            mInst = this;

            //Context.RegisterReceiver(Con);

            //Android.Support.V7.Widget.Toolbar toolbar = FindViewById<Android.Support.V7.Widget.Toolbar>(Resource.Id.toolbar);
            //SetSupportActionBar(toolbar);

            //FloatingActionButton fab = FindViewById<FloatingActionButton>(Resource.Id.fab);
            //fab.Click += FabOnClick;
        }

        //public override bool OnCreateOptionsMenu(IMenu menu)
        //{
        //    MenuInflater.Inflate(Resource.Menu.menu_main, menu);
        //    return true;
        //}

        //public override bool OnOptionsItemSelected(IMenuItem item)
        //{
        //    int id = item.ItemId;
        //    if (id == Resource.Id.action_settings)
        //    {
        //        return true;
        //    }

        //    return base.OnOptionsItemSelected(item);
        //}

        //private void FabOnClick(object sender, EventArgs eventArgs)
        //{
        //    View view = (View) sender;
        //    Snackbar.Make(view, "Replace with your own action", Snackbar.LengthLong)
        //        .SetAction("Action", (Android.Views.View.IOnClickListener)null).Show();
        //}

        //public override void OnRequestPermissionsResult(int requestCode, string[] permissions, [GeneratedEnum] Android.Content.PM.Permission[] grantResults)
        //{
        //    Xamarin.Essentials.Platform.OnRequestPermissionsResult(requestCode, permissions, grantResults);

        //    base.OnRequestPermissionsResult(requestCode, permissions, grantResults);
        //}
    }
}

